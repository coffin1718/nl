echo "Enter two numbers with operator in between"
read a op b

case $op in
"+") echo $(($a+$b));;
"-") echo $(($a-$b));;
"*") echo $(($a*$b));;
"/") echo $(($a/$b));;
esac