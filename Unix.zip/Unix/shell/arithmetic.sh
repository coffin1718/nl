echo "Enter two numbers "
read a b

ad=$(($a + $b))
s=$(($a - $b))
m=$(($a * $b))
d=$(($a / $b))

echo "Addition = $ad"
echo "Subtraction = $s"
echo "Multiplication = $m"
echo "Division = $d"