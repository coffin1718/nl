echo "Enter any 3 numbers"
read a b c

if [ $a -gt $b -a $a -gt $c ]
then
    echo "$a is greatest number"
elif [ $b -gt $a -a $b -gt $c ]
then
    echo "$b is greatest number"
else
    echo "$c is greatest number"
fi