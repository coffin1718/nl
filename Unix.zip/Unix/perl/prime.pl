print "Enter a number = ";
$num=<>;
$flag=0;

for($i=2;$i<$num;$i++){
    if($num % $i == 0 ){
        $flag=1;
    }

}

if($flag){
    print "Not prime";
}
else{
    print "Prime";
}